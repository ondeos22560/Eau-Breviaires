const c=document.getElementById('map'),ctx=c.getContext('2d');
let center={lon:1.8131,lat:48.7075}, zoom=13.5, gps=null, dragging=false,last=null, addMode=false, streetViewMode=false, addLocation=null, userPoints=[], data={water:[],sources:[],points:[],hydro:[],commune:[]};
let gpsWatchId=null;
const tileCache=new Map();
const R=6378137;
function merc(lon,lat){let x=R*lon*Math.PI/180,y=R*Math.log(Math.tan(Math.PI/4+lat*Math.PI/360));return{x,y}}
function inv(x,y){return{lon:x/R*180/Math.PI,lat:(2*Math.atan(Math.exp(y/R))-Math.PI/2)*180/Math.PI}}
function scale(){return 256*Math.pow(2,zoom)/(2*Math.PI*R)}
function viewportSize(){const r=c.getBoundingClientRect();return{w:r.width||document.documentElement.clientWidth,h:r.height||document.documentElement.clientHeight}}
function screen(lon,lat){let p=merc(lon,lat),m=merc(center.lon,center.lat),s=scale(),v=viewportSize();return{x:v.w/2+(p.x-m.x)*s,y:v.h/2-(p.y-m.y)*s}}
function resize(){let d=devicePixelRatio||1,v=viewportSize(),w=Math.round(v.w*d),h=Math.round(v.h*d);if(c.width!==w)c.width=w;if(c.height!==h)c.height=h;ctx.setTransform(d,0,0,d,0,0);draw()}
function grid(){const v=viewportSize();ctx.fillStyle='#e6eee5';ctx.fillRect(0,0,v.w,v.h);ctx.strokeStyle='#cbd9cc';ctx.lineWidth=1;for(let x=0;x<v.w;x+=60){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,v.h);ctx.stroke()}for(let y=0;y<v.h;y+=60){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(v.w,y);ctx.stroke()}}
function lonLatToTilePixel(lon,lat,z){const n=Math.pow(2,z),x=(lon+180)/360*n*256;const lr=lat*Math.PI/180,y=(1-Math.asinh(Math.tan(lr))/Math.PI)/2*n*256;return{x,y}}
function activeBasemap(){if(document.getElementById('satellite')?.checked)return'satellite';if(document.getElementById('online')?.checked)return'osm';return'local'}
function tileUrl(type,z,x,y){if(type==='osm')return`https://tile.openstreetmap.org/${z}/${x}/${y}.png`;return`https://data.geopf.fr/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=ORTHOIMAGERY.ORTHOPHOTOS&STYLE=normal&FORMAT=image/jpeg&TILEMATRIXSET=PM&TILEMATRIX=${z}&TILEROW=${y}&TILECOL=${x}`}
function drawTiles(type){
  const z=Math.max(0,Math.min(19,Math.round(zoom))),n=Math.pow(2,z),factor=Math.pow(2,zoom-z),tileSize=256*factor;
  const cp=lonLatToTilePixel(center.lon,center.lat,z),cx=cp.x*factor,cy=cp.y*factor;
  const v=viewportSize(),left=cx-v.w/2,top=cy-v.h/2;
  const minX=Math.floor(left/tileSize),maxX=Math.floor((left+v.w)/tileSize),minY=Math.max(0,Math.floor(top/tileSize)),maxY=Math.min(n-1,Math.floor((top+v.h)/tileSize));
  for(let tx=minX;tx<=maxX;tx++)for(let ty=minY;ty<=maxY;ty++){
    const wrapped=((tx%n)+n)%n,key=`${type}/${z}/${wrapped}/${ty}`,sx=tx*tileSize-left,sy=ty*tileSize-top;
    let img=tileCache.get(key);
    if(!img){img=new Image();img.crossOrigin='anonymous';img.retryCount=0;img.onload=()=>{img.failed=false;draw()};img.onerror=()=>{img.failed=true;if(type==='satellite'&&img.retryCount<3){img.retryCount++;setTimeout(()=>{img.failed=false;img.src=tileUrl(type,z,wrapped,ty)+'&_retry='+img.retryCount},500*img.retryCount)}else draw()};img.src=tileUrl(type,z,wrapped,ty);tileCache.set(key,img)}
    if(img.complete&&!img.failed&&img.naturalWidth)ctx.drawImage(img,sx,sy,tileSize+1,tileSize+1);
  }
}
function point(lon,lat,r,fill,stroke='#fff'){let p=screen(lon,lat);ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);ctx.fillStyle=fill;ctx.fill();ctx.lineWidth=3;ctx.strokeStyle=stroke;ctx.stroke();return p}
function line(coords,color='#087fb5',w=3){const pts=coords.map(q=>screen(q[0],q[1]));if(!pts.length)return;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle='rgba(255,255,255,.88)';ctx.lineWidth=w+4;ctx.stroke();ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle=color;ctx.lineWidth=w;ctx.stroke()}
function polygon(rings,fill='rgba(0,126,183,.28)',stroke='#007eb7'){rings.forEach(ring=>{ctx.beginPath();ring.forEach((q,i)=>{const p=screen(q[0],q[1]);i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)});ctx.closePath();ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle='rgba(255,255,255,.9)';ctx.lineWidth=5;ctx.stroke();ctx.strokeStyle=stroke;ctx.lineWidth=2.5;ctx.stroke()})}
function drawFeature(f,color,kind='generic'){let g=f.geometry;if(!g)return;if(g.type==='Point')point(g.coordinates[0],g.coordinates[1],zoom<14?7:6,color);if(g.type==='LineString'&&zoom>=12.5)line(g.coordinates,color,3);if(g.type==='MultiLineString'&&zoom>=12.5)g.coordinates.forEach(x=>line(x,color,3));if(g.type==='Polygon'&&zoom>=13.5)polygon(g.coordinates);if(g.type==='MultiPolygon'&&zoom>=13.5)g.coordinates.forEach(x=>polygon(x))}
function featureCenter(f){const g=f.geometry;if(!g)return null;if(g.type==='Point')return g.coordinates;if(g.type==='Polygon'&&g.coordinates?.[0]?.length){const a=g.coordinates[0];return [a.reduce((s,q)=>s+q[0],0)/a.length,a.reduce((s,q)=>s+q[1],0)/a.length]}if(g.type==='MultiPolygon'&&g.coordinates?.[0]?.[0]?.length){const a=g.coordinates[0][0];return [a.reduce((s,q)=>s+q[0],0)/a.length,a.reduce((s,q)=>s+q[1],0)/a.length]}return null}
function updateAttribution(type){const el=document.getElementById('attribution');if(type==='osm'){el.innerHTML='© OpenStreetMap contributors';el.classList.remove('hidden')}else if(type==='satellite'){el.innerHTML='Photographies aériennes © IGN';el.classList.remove('hidden')}else el.classList.add('hidden')}
function draw(){const base=activeBasemap();grid();if(base!=='local')drawTiles(base);updateAttribution(base);if(document.getElementById('showHydro').checked)data.hydro.forEach(f=>drawFeature(f,'#087fb5','hydro'));if(document.getElementById('showWater').checked)data.water.forEach(f=>drawFeature(f,'#007eb7','water'));if(document.getElementById('showSources').checked)data.sources.forEach(f=>drawFeature(f,'#00a86b','source'));if(document.getElementById('showPoints').checked)data.points.forEach(f=>drawFeature(f,'#7a5cff','point'));if(document.getElementById('showUserPoints').checked)userPoints.forEach(f=>drawFeature(f,'#d7191c','point'));if(addLocation)point(addLocation.lon,addLocation.lat,8,'#d7191c','#fff');if(document.getElementById('showCommune').checked)data.commune.forEach(f=>drawFeature(f,'#496d54'));if(gps){const gp=screen(gps.lon,gps.lat);if(gps.acc){const rr=Math.min(80,Math.max(10,gps.acc*scale()));ctx.beginPath();ctx.arc(gp.x,gp.y,rr,0,Math.PI*2);ctx.fillStyle='rgba(255,255,255,.16)';ctx.fill();ctx.strokeStyle='rgba(20,20,20,.38)';ctx.lineWidth=1.5;ctx.stroke()}point(gps.lon,gps.lat,11,'#ffffff','#263238');point(gps.lon,gps.lat,7,'#00d4d8','#ffffff');point(gps.lon,gps.lat,3,'#00d4d8','#263238')}}
async function load(){
  const sources=[['water','data/plans_eau.geojson'],['sources','data/sources.geojson'],['points','data/points_eau.geojson'],['hydro','data/hydrographie.geojson'],['commune','data/commune.geojson']];
  const errors=[];
  for(const [k,f] of sources){
    try{
      const j=await fetch(f,{cache:'no-store'});
      if(!j.ok)throw new Error(`HTTP ${j.status}`);
      const geo=await j.json();
      data[k]=Array.isArray(geo.features)?geo.features:[];
    }catch(e){errors.push(`${k}: ${e.message}`)}
  }
  const waterLabel=document.querySelector('label[for="showWater"]');
  if(waterLabel)waterLabel.innerHTML=`<span class="dot water"></span>Mares / plans d'eau (${data.water.length})`;
  const sourceLabel=document.querySelector('label[for="showSources"]');if(sourceLabel)sourceLabel.innerHTML=`<span class="dot source"></span>Sources / résurgences (${data.sources.length})`;
  const pointLabel=document.querySelector('label[for="showPoints"]');if(pointLabel)pointLabel.innerHTML=`<span class="dot other-water"></span>Autres points d'eau (${data.points.length})`;
  const userPointLabel=document.querySelector('label[for="showUserPoints"]');if(userPointLabel)userPointLabel.innerHTML=`<span class="dot user-point"></span>Points nouveaux (${userPoints.length})`;
  const hydroLabel=document.querySelector('label[for="showHydro"]');if(hydroLabel)hydroLabel.innerHTML=`<span class="line-key hydro-key"></span>Hydrographie (${data.hydro.length})`;
  status.textContent=errors.length?`Données partielles • ${data.water.length} points d’eau chargés`:'';
  draw();
}
function coordFromEvent(e){let rect=c.getBoundingClientRect();return{x:e.clientX-rect.left,y:e.clientY-rect.top}}
const pointers=new Map();let pinchDistance=null;
function pointerDistance(){const a=[...pointers.values()];return a.length<2?null:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)}
c.addEventListener('pointerdown',e=>{const p=coordFromEvent(e);pointers.set(e.pointerId,p);c.setPointerCapture(e.pointerId);if(pointers.size===1){dragging=true;last=p}else{dragging=false;pinchDistance=pointerDistance()}});
c.addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId))return;const p=coordFromEvent(e);pointers.set(e.pointerId,p);if(pointers.size>=2){const d=pointerDistance();if(pinchDistance&&d){zoom=Math.max(10,Math.min(19,zoom+Math.log2(d/pinchDistance)));pinchDistance=d;draw()}return}if(!dragging)return;let dx=p.x-last.x,dy=p.y-last.y,m=merc(center.lon,center.lat),s=scale();center=inv(m.x-dx/s,m.y+dy/s);last=p;draw()});
function endPointer(e){pointers.delete(e.pointerId);pinchDistance=null;if(pointers.size===1){dragging=true;last=[...pointers.values()][0]}else dragging=false}
c.addEventListener('pointerup',endPointer);c.addEventListener('pointercancel',endPointer);c.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(10,Math.min(19,zoom+(e.deltaY<0?.5:-.5)));draw()},{passive:false});
function closePopup(){popup.classList.add('hidden');popup.style.left='';popup.style.top=''}
function updateUserPointTools(){const b=document.getElementById('exportKmlBtn');if(b)b.classList.toggle('hidden',userPoints.length===0)}
function streetViewUrl(lon,lat){return`https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${lat},${lon}`}
function xmlEscape(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]))}
async function exportUserPointsKml(){
  if(!userPoints.length)return;
  const placemarks=userPoints.map((f,i)=>{const a=f.properties||{},q=f.geometry?.coordinates||[];if(q.length<2)return'';const d=a.description||`Point nouveau ${i+1}`,date=a.date_heure||'';const sv=streetViewUrl(q[0],q[1]);return`<Placemark><name>${xmlEscape(d)}</name><description>${xmlEscape(`Description : ${d}\nDate/heure : ${date||'non renseignée'}\nLatitude : ${q[1]}\nLongitude : ${q[0]}\nStreet View : ${sv}`)}</description><Point><coordinates>${q[0]},${q[1]},0</coordinates></Point></Placemark>`}).join('');
  const kml=`<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Points nouveaux - Eau Les Bréviaires</name>${placemarks}</Document></kml>`;
  const filename=`points_eau_breviaires_${new Date().toISOString().slice(0,10)}.kml`,blob=new Blob([kml],{type:'application/vnd.google-earth.kml+xml'}),file=new File([blob],filename,{type:'application/vnd.google-earth.kml+xml'});
  const mobile=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  if(mobile&&navigator.share&&(!navigator.canShare||navigator.canShare({files:[file]}))){try{await navigator.share({title:'Points nouveaux – Eau Les Bréviaires',text:'Points relevés sur le terrain.',files:[file]});status.textContent=`${userPoints.length} point(s) prêt(s) à être envoyé(s)`;return}catch(e){if(e.name==='AbortError'){status.textContent='Partage annulé';return}}}
  const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);status.textContent=`${userPoints.length} point(s) exporté(s) en KML`;
}
function placePopup(p){const margin=10,v=viewportSize(),w=Math.min(390,v.w-24);let left=Math.max(margin,Math.min(v.w-w-margin,p.x-w/2));let top=p.y+16;popup.style.width=w+'px';popup.style.left=left+'px';popup.style.top=top+'px';popup.style.bottom='auto';popup.style.transform='none';popup.classList.remove('hidden');requestAnimationFrame(()=>{const h=popup.offsetHeight;if(top+h>v.h-margin){top=Math.max(margin,p.y-h-16);popup.style.top=top+'px'}})}
function pointToSegmentDistance(p,a,b){const vx=b.x-a.x,vy=b.y-a.y,wx=p.x-a.x,wy=p.y-a.y,c2=vx*vx+vy*vy;if(!c2)return Math.hypot(p.x-a.x,p.y-a.y);const t=Math.max(0,Math.min(1,(wx*vx+wy*vy)/c2)),x=a.x+t*vx,y=a.y+t*vy;return Math.hypot(p.x-x,p.y-y)}
function ringContainsPoint(p,ring){let inside=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){const a=screen(ring[i][0],ring[i][1]),b=screen(ring[j][0],ring[j][1]);if(((a.y>p.y)!==(b.y>p.y))&&(p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x))inside=!inside}return inside}
function featureHitDistance(f,p){const g=f.geometry;if(!g)return Infinity;if(g.type==='Point'){const q=screen(g.coordinates[0],g.coordinates[1]);return Math.hypot(q.x-p.x,q.y-p.y)}if(g.type==='LineString'){let d=Infinity;for(let i=1;i<g.coordinates.length;i++)d=Math.min(d,pointToSegmentDistance(p,screen(...g.coordinates[i-1]),screen(...g.coordinates[i])));return d}if(g.type==='MultiLineString'){return Math.min(...g.coordinates.map(a=>featureHitDistance({geometry:{type:'LineString',coordinates:a}},p)))}if(g.type==='Polygon'){if(g.coordinates[0]&&ringContainsPoint(p,g.coordinates[0]))return 0;return Infinity}if(g.type==='MultiPolygon'){for(const poly of g.coordinates)if(poly[0]&&ringContainsPoint(p,poly[0]))return 0;return Infinity}return Infinity}
function featureName(f){const a=f.properties||{};return a.nom||a.TopoOH||a.name||a.type_carto||a.type||a.nature||'Élément hydrographique'}
function removeUserPoint(f){const i=userPoints.indexOf(f);if(i<0)return;if(!confirm('Supprimer définitivement ce point ajouté ?'))return;userPoints.splice(i,1);localStorage.setItem('eauBreviairesUserPoints',JSON.stringify(userPoints));closePopup();const userPointLabel=document.querySelector('label[for="showUserPoints"]');if(userPointLabel)userPointLabel.innerHTML=`<span class="dot user-point"></span>Points nouveaux (${userPoints.length})`;status.textContent='Point utilisateur supprimé';updateUserPointTools();draw()}
function showFeaturePopup(f,p){const a=f.properties||{},isUser=userPoints.includes(f);if(isUser){const description=a.description||a.commentaire||a.nom||'',q=f.geometry?.coordinates||[],date=a.date_heure||'';popup.innerHTML=`<button class="popup-close" type="button" aria-label="Fermer">×</button><b>Point nouveau</b><small>${description?`Description : ${description}`:'Aucune description'}${date?`<br>Date/heure : ${date}`:''}${q.length>=2?`<br>Coordonnées : ${q[1].toFixed(6)}, ${q[0].toFixed(6)}`:''}</small>${q.length>=2?'<button class="streetview-user-point" type="button">Ouvrir Street View</button>':''}<button class="remove-user-point" type="button">Supprimer ce point</button>`}else{const nom=featureName(f),type=a.type_carto||a.type||a.nature||'';popup.innerHTML=`<button class="popup-close" type="button" aria-label="Fermer">×</button><b>${nom}</b>${type?`${type}<br>`:''}<small>Source : ${a.source||'non renseignée'}<br>Potabilité : ${a.potabilite||'non renseignée'}<br>${a.statut||a.StatutOH||''}${a.commentaire||a.CommentaireOH?`<br>Commentaire : ${a.commentaire||a.CommentaireOH}`:''}</small>`}popup.querySelector('.popup-close').onclick=closePopup;if(isUser){popup.querySelector('.remove-user-point').onclick=()=>removeUserPoint(f);const sv=popup.querySelector('.streetview-user-point');if(sv)sv.onclick=()=>{const q=f.geometry.coordinates;window.open(streetViewUrl(q[0],q[1]),'_blank','noopener')}}placePopup(p)}
c.addEventListener('click',e=>{
  if(Math.abs(e.movementX||0)+Math.abs(e.movementY||0)>3)return;
  const p=coordFromEvent(e),m=merc(center.lon,center.lat),sc=scale(),v=viewportSize(),ll=inv(m.x+(p.x-v.w/2)/sc,m.y-(p.y-v.h/2)/sc);
  if(streetViewMode){streetViewMode=false;streetViewBtn.classList.remove('active');status.textContent='';window.open(streetViewUrl(ll.lon,ll.lat),'_blank','noopener');return}
  if(addMode){addLocation=ll;addCoords.textContent=`Position : ${ll.lat.toFixed(6)}, ${ll.lon.toFixed(6)}`;addForm.classList.remove('hidden');addMode=false;status.textContent='Compléter la fiche du point';draw();return}
  let best=null,bd=22;
  const groups=[showUserPoints.checked?userPoints:[],showWater.checked?data.water:[],showSources.checked?data.sources:[],showPoints.checked?data.points:[],showHydro.checked?data.hydro:[]];
  for(const group of groups){for(const f of group){const d=featureHitDistance(f,p);if(d<bd){best=f;bd=d}}if(best)break}
  if(best)showFeaturePopup(best,p);else closePopup();
});
layersBtn.onclick=()=>{closePopup();panel.classList.toggle('hidden')};document.getElementById('closeLayers').onclick=()=>panel.classList.add('hidden');['showWater','showSources','showPoints','showUserPoints','showHydro','showCommune'].forEach(id=>document.getElementById(id).onchange=draw);document.getElementById('exportKmlBtn').onclick=exportUserPointsKml;
function setBasemap(which){online.checked=which==='osm';satellite.checked=which==='satellite';status.textContent='';draw()}
online.onchange=()=>setBasemap(online.checked?'osm':'local');satellite.onchange=()=>setBasemap(satellite.checked?'satellite':'local');
gpsBtn.onclick=()=>{
  if(!navigator.geolocation){status.textContent='GPS non disponible';return}
  if(gpsWatchId!==null){navigator.geolocation.clearWatch(gpsWatchId);gpsWatchId=null;gpsBtn.classList.remove('active');status.textContent='GPS arrêté';return}
  status.textContent='Recherche GPS…';gpsBtn.classList.add('active');
  gpsWatchId=navigator.geolocation.watchPosition(p=>{gps={lon:p.coords.longitude,lat:p.coords.latitude,acc:p.coords.accuracy};center={lon:gps.lon,lat:gps.lat};zoom=16;status.textContent=`GPS actif • précision ±${Math.round(gps.acc)} m`;draw()},e=>{gpsBtn.classList.remove('active');gpsWatchId=null;status.textContent='GPS : '+e.message},{enableHighAccuracy:true,maximumAge:5000,timeout:15000});
};

try{userPoints=JSON.parse(localStorage.getItem('eauBreviairesUserPoints')||'[]');if(!Array.isArray(userPoints))userPoints=[]}catch(e){userPoints=[]}updateUserPointTools();if(/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)){const b=document.getElementById('exportKmlBtn');if(b)b.textContent='Partager les points en KML'}
streetViewBtn.onclick=()=>{streetViewMode=!streetViewMode;addMode=false;addLocation=null;addForm.classList.add('hidden');panel.classList.add('hidden');closePopup();streetViewBtn.classList.toggle('active',streetViewMode);status.textContent=streetViewMode?'Cliquez sur la carte pour ouvrir Street View':'';draw()};
addBtn.onclick=()=>{streetViewMode=false;streetViewBtn.classList.remove('active');addMode=true;addLocation=null;closePopup();panel.classList.add('hidden');addForm.classList.add('hidden');status.textContent='Touchez la carte à l’emplacement du point à ajouter';draw()};
closeAdd.onclick=()=>{addForm.classList.add('hidden');addLocation=null;addMode=false;status.textContent='Ajout annulé';draw()};
removeAdd.onclick=()=>{addForm.classList.add('hidden');addLocation=null;addMode=false;status.textContent='Point retiré • ajout annulé';draw()};
saveAdd.onclick=()=>{if(!addLocation)return;const description=addDescription.value.trim();const f={type:'Feature',properties:{type:'Point nouveau',description,date_heure:new Date().toLocaleString('fr-FR'),source:'Contribution utilisateur locale',statut:'À vérifier'},geometry:{type:'Point',coordinates:[addLocation.lon,addLocation.lat]}};userPoints.push(f);localStorage.setItem('eauBreviairesUserPoints',JSON.stringify(userPoints));addForm.classList.add('hidden');addDescription.value='';addLocation=null;const userPointLabel=document.querySelector('label[for="showUserPoints"]');if(userPointLabel)userPointLabel.innerHTML=`<span class="dot user-point"></span>Points nouveaux (${userPoints.length})`;
  const hydroLabel=document.querySelector('label[for="showHydro"]');if(hydroLabel)hydroLabel.innerHTML=`<span class="line-key hydro-key"></span>Hydrographie (${data.hydro.length})`;status.textContent='Point enregistré sur cet appareil • à vérifier';updateUserPointTools();draw()};

setBasemap('osm');
if('serviceWorker'in navigator)navigator.serviceWorker.register('./service-worker.js').catch(()=>{});addEventListener('resize',resize);if(window.visualViewport){visualViewport.addEventListener('resize',resize);visualViewport.addEventListener('scroll',resize)}resize();load();
